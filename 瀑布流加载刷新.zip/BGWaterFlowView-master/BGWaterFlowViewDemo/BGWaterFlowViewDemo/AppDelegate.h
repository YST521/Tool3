//
//  AppDelegate.h
//  BGWaterFlowViewDemo
//
//  Created by user on 15/11/7.
//  Copyright © 2015年 BG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

