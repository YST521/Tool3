//
//  MyDIYViewController.h
//  LYEmptyViewDemo
//
//  Created by 李阳 on 2017/5/27.
//  Copyright © 2017年 liyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyDIYViewController : UIViewController

@property (nonatomic, copy) NSDictionary *dataDic;

@end
