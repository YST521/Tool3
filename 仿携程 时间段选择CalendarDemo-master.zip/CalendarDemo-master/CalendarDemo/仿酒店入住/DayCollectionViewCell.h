//
//  DayCollectionViewCell.h
//  BJTResearch
//
//  Created by yunlong on 17/5/11.
//  Copyright © 2017年 yunlong. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DayModel;
@interface DayCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong) DayModel *model;
@end
