//
//  MonthModel.m
//  BJTResearch
//
//  Created by yunlong on 17/5/12.
//  Copyright © 2017年 yunlong. All rights reserved.
//

#import "MonthModel.h"


@implementation DayModel

@end
@implementation MonthModel

@end
