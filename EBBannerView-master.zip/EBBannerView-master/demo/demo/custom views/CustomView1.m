//
//  CustomView1.m
//  demo
//
//  Created by wxc on 2017/10/30.
//  Copyright © 2017年 吴星辰. All rights reserved.
//

#import "CustomView1.h"

#import "EBCustomBannerView.h"

@implementation CustomView1

- (IBAction)close:(id)sender {
    
    [self.customView hide];
}


@end
