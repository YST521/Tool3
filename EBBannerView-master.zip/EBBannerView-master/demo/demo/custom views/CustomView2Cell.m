//
//  CustomView2Cell.m
//  demo
//
//  Created by wxc on 2017/10/30.
//  Copyright © 2017年 吴星辰. All rights reserved.
//

#import "CustomView2Cell.h"

#import "EBCustomBannerView.h"

@implementation CustomView2Cell

- (IBAction)close:(id)sender {
    [self.customView hide];
}

@end
