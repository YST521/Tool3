//
//  CustomView2.h
//  demo
//
//  Created by wxc on 2017/10/30.
//  Copyright © 2017年 吴星辰. All rights reserved.
//

#import <UIKit/UIKit.h>
@class EBCustomBannerView;

@interface CustomView2 : UIView
@property(nonatomic, weak)EBCustomBannerView *customView;

@end
