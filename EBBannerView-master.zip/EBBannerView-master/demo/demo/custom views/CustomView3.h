//
//  CustomView3.h
//  demo
//
//  Created by wxc on 2017/10/30.
//  Copyright © 2017年 吴星辰. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "EBCustomBannerView.h"

@interface CustomView3 : UIView

@property(nonatomic, weak)EBCustomBannerView *customView;

@end
